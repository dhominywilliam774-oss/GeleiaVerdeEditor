package com.geleiaverde.editor

import android.content.ContentValues
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.geleiaverde.editor.databinding.ActivityMainBinding
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@UnstableApi
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var player: ExoPlayer? = null
    private var currentVideo: Uri? = null
    private var videoDurationMs: Long = 0L
    private var trimStartMs: Long = 0L
    private var trimEndMs: Long = 0L
    private var transformer: Transformer? = null
    private var exportFile: File? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val progressHolder = ProgressHolder()
    private var progressRunnable: Runnable? = null

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) {
                // Alguns provedores não permitem persistir a permissão; o vídeo ainda pode ser usado nesta sessão.
            }
            loadVideo(uri)
        }
    }

    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            Toast.makeText(this, "Áudio selecionado. A mixagem ainda não está implementada nesta versão.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        player = ExoPlayer.Builder(this).build().also { exo ->
            binding.playerView.player = exo
            exo.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) {
                        binding.emptyPreview.visibility = View.GONE
                        videoDurationMs = exo.duration.coerceAtLeast(0L)
                        if (trimEndMs == 0L || trimEndMs > videoDurationMs) trimEndMs = videoDurationMs
                        updateTimelineLabel()
                    }
                }
            })
        }

        binding.importButton.setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        binding.musicButton.setOnClickListener { pickAudio.launch(arrayOf("audio/*")) }
        binding.textButton.setOnClickListener {
            Toast.makeText(this, "Texto e legendas ainda não estão implementados nesta versão.", Toast.LENGTH_LONG).show()
        }
        binding.cutButton.setOnClickListener { showTrimDialog() }
        binding.exportButton.setOnClickListener { exportTrimmedVideo() }
    }

    private fun loadVideo(uri: Uri) {
        currentVideo = uri
        trimStartMs = 0L
        trimEndMs = 0L
        videoDurationMs = readDuration(uri)
        if (videoDurationMs > 0L) trimEndMs = videoDurationMs
        binding.projectStatus.text = "Vídeo importado • pronto para pré-visualização"
        binding.emptyPreview.visibility = View.GONE
        player?.apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = false
        }
        updateTimelineLabel()
    }

    private fun readDuration(uri: Uri): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(this, uri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            0L
        } finally {
            try { retriever.release() } catch (_: Exception) { }
        }
    }

    private fun showTrimDialog() {
        val uri = currentVideo
        if (uri == null) {
            Toast.makeText(this, "Importe um vídeo primeiro.", Toast.LENGTH_SHORT).show()
            return
        }
        val startInput = EditText(this).apply {
            hint = "Início em segundos (ex.: 0)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText((trimStartMs / 1000.0).formatSeconds())
        }
        val endInput = EditText(this).apply {
            hint = "Fim em segundos"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText((trimEndMs.takeIf { it > 0 } ?: videoDurationMs).div(1000.0).formatSeconds())
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 12, 48, 0)
            addView(TextView(this@MainActivity).apply {
                text = "Defina o trecho que será exportado. Use segundos; por exemplo, 2,5."
            })
            addView(startInput)
            addView(endInput)
        }
        AlertDialog.Builder(this)
            .setTitle("Cortar vídeo")
            .setView(layout)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Aplicar") { _, _ ->
                val startSeconds = startInput.text.toString().trim().replace(',', '.').toDoubleOrNull()
                val endSeconds = endInput.text.toString().trim().replace(',', '.').toDoubleOrNull()
                if (startSeconds == null || endSeconds == null || startSeconds < 0 || endSeconds <= startSeconds) {
                    Toast.makeText(this, "Informe um início e um fim válidos.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val start = (startSeconds * 1000).toLong()
                val end = (endSeconds * 1000).toLong()
                if (videoDurationMs > 0 && end > videoDurationMs) {
                    Toast.makeText(this, "O fim ultrapassa a duração do vídeo.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                trimStartMs = start
                trimEndMs = end
                updateTimelineLabel()
                binding.projectStatus.text = "Trecho selecionado • ${startSeconds.formatSeconds()}s até ${endSeconds.formatSeconds()}s"
                player?.seekTo(trimStartMs)
            }
            .show()
    }

    private fun updateTimelineLabel() {
        val name = currentVideo?.lastPathSegment?.substringAfterLast('/') ?: "vídeo selecionado"
        val end = trimEndMs.takeIf { it > 0L } ?: videoDurationMs
        binding.timelineLabel.text = if (currentVideo == null) {
            "Importe um vídeo para preencher a linha do tempo"
        } else {
            "$name\nTrecho: ${(trimStartMs / 1000.0).formatSeconds()}s – ${(end / 1000.0).formatSeconds()}s"
        }
    }

    private fun exportTrimmedVideo() {
        val uri = currentVideo
        if (uri == null) {
            Toast.makeText(this, "Importe um vídeo primeiro.", Toast.LENGTH_SHORT).show()
            return
        }
        val duration = videoDurationMs.takeIf { it > 0L } ?: readDuration(uri)
        val end = trimEndMs.takeIf { it > 0L } ?: duration
        if (end <= trimStartMs || (duration > 0L && end > duration)) {
            Toast.makeText(this, "Confira o trecho em Cortar antes de exportar.", Toast.LENGTH_LONG).show()
            return
        }
        if (transformer != null) {
            Toast.makeText(this, "Já existe uma exportação em andamento.", Toast.LENGTH_SHORT).show()
            return
        }

        val mediaItem = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(trimStartMs)
                    .setEndPositionMs(end)
                    .build()
            )
            .build()
        val editedItem = EditedMediaItem.Builder(mediaItem)
            .setFrameRate(60)
            .setEffects(Effects(emptyList(), listOf(Presentation.createForHeight(1080))))
            .build()
        val outputDir = File(cacheDir, "exports").apply { mkdirs() }
        exportFile = File(outputDir, "geleia_${System.currentTimeMillis()}.mp4")
        val outputPath = exportFile!!.absolutePath

        binding.exportButton.isEnabled = false
        binding.projectStatus.text = "Exportando vídeo… mantenha o app aberto"
        transformer = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    stopProgressPolling()
                    val file = exportFile
                    transformer = null
                    if (file == null || !file.exists()) {
                        finishExportUi("Não foi possível encontrar o vídeo exportado.")
                        return
                    }
                    try {
                        val savedUri = saveToGallery(file)
                        finishExportUi("Exportação concluída! Vídeo salvo na galeria.")
                        Toast.makeText(this@MainActivity, "Vídeo salvo na galeria.", Toast.LENGTH_LONG).show()
                        binding.projectStatus.text = "Concluído • ${savedUri.lastPathSegment ?: "vídeo exportado"}"
                    } catch (e: Exception) {
                        finishExportUi("Exportou, mas não foi possível salvar na galeria: ${e.message ?: "erro desconhecido"}")
                    } finally {
                        file.delete()
                    }
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    stopProgressPolling()
                    transformer = null
                    exportFile?.delete()
                    finishExportUi("Falha ao exportar: ${exportException.message ?: "formato de vídeo não suportado"}")
                }
            })
            .build()
        startProgressPolling()
        try {
            transformer?.start(editedItem, outputPath)
        } catch (e: Exception) {
            stopProgressPolling()
            transformer = null
            exportFile?.delete()
            finishExportUi("Não foi possível iniciar a exportação: ${e.message ?: "erro"}")
        }
    }

    private fun startProgressPolling() {
        stopProgressPolling()
        progressRunnable = object : Runnable {
            override fun run() {
                val activeTransformer = transformer ?: return
                val state = activeTransformer.getProgress(progressHolder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    binding.projectStatus.text = "Exportando vídeo… ${progressHolder.progress}%"
                }
                mainHandler.postDelayed(this, 400L)
            }
        }
        mainHandler.post(progressRunnable!!)
    }

    private fun stopProgressPolling() {
        progressRunnable?.let { mainHandler.removeCallbacks(it) }
        progressRunnable = null
    }

    private fun finishExportUi(message: String) {
        binding.exportButton.isEnabled = true
        binding.projectStatus.text = message
        if (message.startsWith("Falha") || message.startsWith("Não foi")) {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }

    @Throws(IOException::class)
    private fun saveToGallery(file: File): Uri {
        val name = "GeleiaVerde_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/GeleiaVerdeEditor")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val uri = contentResolver.insert(collection, values) ?: throw IOException("Não foi possível criar o arquivo na galeria")
        try {
            contentResolver.openOutputStream(uri)?.use { output ->
                FileInputStream(file).use { input -> input.copyTo(output) }
            } ?: throw IOException("Não foi possível abrir o arquivo de destino")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val complete = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                contentResolver.update(uri, complete, null, null)
            }
            return uri
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            throw e
        }
    }

    override fun onDestroy() {
        stopProgressPolling()
        transformer?.cancel()
        transformer = null
        binding.playerView.player = null
        player?.release()
        player = null
        super.onDestroy()
    }

    private fun Double.formatSeconds(): String = String.format(Locale.getDefault(), "%.1f", this).trimEnd('0').trimEnd(',', '.')
}

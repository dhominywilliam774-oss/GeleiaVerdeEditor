# Geleia Verde Editor

Aplicativo Android nativo em Kotlin, com interface escura e identidade verde.

## O que está implementado nesta versão

- Importação de vídeos pelo seletor de arquivos do Android.
- Pré-visualização e reprodução com AndroidX Media3 / ExoPlayer.
- Seleção de início e fim do trecho em segundos.
- Exportação real do trecho selecionado para MP4 usando Media3 Transformer, configurada para H.264/AAC, altura de saída de 1080 pixels e limite de 60 FPS quando suportado.
- Exibição do progresso de exportação quando o motor disponibiliza o progresso.
- Salvamento do resultado na biblioteca de vídeos, na pasta `Movies/GeleiaVerdeEditor` em Android 10 ou superior.
- Estrutura de projeto Gradle e workflow do GitHub Actions para tentar compilar um APK de depuração.

## Ainda não implementado

- Mixagem do áudio importado (o seletor de áudio é apenas informativo por enquanto).
- Texto, legendas e adesivos sobre o vídeo.
- Transições, filtros e efeitos visuais.
- Linha do tempo multipista com vários clipes.
- Seletor de resolução e FPS. A exportação tenta usar altura de 1080 pixels e H.264/AAC, com limite máximo de 60 FPS. Vídeos de origem abaixo de 60 FPS não são convertidos para 60 FPS por esta configuração. A compatibilidade e o resultado final dependem do vídeo, do codificador do aparelho e do desempenho térmico; não é possível garantir o resultado em todos os celulares.
- Testes em aparelhos físicos.

## Compilar no computador

Requisitos: Android Studio recente, JDK 17 e Android SDK 35.

1. Abra a pasta `GeleiaVerdeEditor` no Android Studio.
2. Aguarde a sincronização do Gradle e o download das dependências.
3. Selecione **Build > Build APK(s)**.
4. O APK de depuração deverá aparecer em `app/build/outputs/apk/debug/app-debug.apk` se a compilação terminar com sucesso.

## GitHub Actions

O workflow `.github/workflows/android.yml` tenta compilar o APK quando houver push ou execução manual. No GitHub, abra a aba **Actions**, selecione a execução e baixe o artefato `GeleiaVerdeEditor-debug-apk` se o build tiver sucesso.

## Limitações importantes

O código foi preparado para a próxima etapa, mas este ambiente de trabalho não tem Android SDK nem Gradle instalados; por isso, não foi possível confirmar uma compilação real nem testar a exportação em um telefone. A compilação do GitHub Actions ou do Android Studio precisa passar antes de considerar o APK pronto para instalação.
